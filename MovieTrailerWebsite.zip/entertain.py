"""
Module that uses the content of media.py to define Class Movie
"""


import fresh_tomatoes
import media

# These are multiple instances of the Class Movie
thegidi = media.Movie("Thegidi",
                      "A story of a man who is a great observer",
                      "http://goo.gl/dRWnqY",
                      "https://youtu.be/7G56AzBxVR8")

theri = media.Movie("Theri",
                    "A Life of a policeman",
                    "http://goo.gl/URW1cs",
                    "http://youtu.be/QqqHOuEngQM")


dunkirk = media.Movie("Dunkirk", "It is a real history about war",
                      "https://goo.gl/G2es4h",
                      "https://youtu.be/F-eMt3SrfFU")


the_emoji_movie = media.Movie("The Emoji Movie",
                              "It is a comedy movie",
                              "https://goo.gl/t5tzFM",
                              "https://youtu.be/o_nfdzMhmrA")


baby_driver = media.Movie("Baby Driver",
                          "A Young driver works for crime boss",
                          "https://goo.gl/QW35d1",
                          "https://youtu.be/z2z857RSfhk")


ragnarok = media.Movie("Ragnarok",
                       "Imprisoned on the other side of the universe",
                       "https://goo.gl/gA9Thu",
                       "https://youtu.be/v7MGUNV8MxU")


# A variable called Movies is created,
# to store an array of movie list
flims = [thegidi, theri, dunkirk, the_emoji_movie, baby_driver, ragnarok]

# A function "open_movies_page" is called,
# The movie list is passed to this function
# as inputs, which translates it into a webpage
# when we run the entertain.py or fresh_tomatoes.py program
fresh_tomatoes.open_movies_page(flims)
